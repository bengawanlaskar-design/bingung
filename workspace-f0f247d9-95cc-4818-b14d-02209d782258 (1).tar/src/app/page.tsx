'use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { toast } from '@/hooks/use-toast'
import {
  Image as ImageIcon,
  Sparkles,
  Trash2,
  Download,
  ZoomIn,
  X,
  Monitor,
  Globe,
  Smartphone,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Clock,
  Info,
  Trash,
  ExternalLink,
} from 'lucide-react'

interface ImageData {
  id: string
  prompt: string
  size: string
  createdAt: string
  userIP?: string
  browser?: string
  os?: string
  device?: string
  imageData?: string
}

interface UserInfo {
  ip: string
  browser: string
  os: string
  device: string
  userAgent: string
}

const IMAGE_SIZES = [
  { value: '1024x1024', label: '1024x1024 (Square)', description: 'Best for portraits' },
  { value: '768x1344', label: '768x1344 (Portrait)', description: 'Vertical format' },
  { value: '864x1152', label: '864x1152 (Portrait HD)', description: 'HD Portrait' },
  { value: '1344x768', label: '1344x768 (Landscape)', description: 'Wide format' },
  { value: '1152x864', label: '1152x864 (Landscape HD)', description: 'HD Landscape' },
  { value: '1440x720', label: '1440x720 (Ultra Wide)', description: 'Cinematic' },
  { value: '720x1440', label: '720x1440 (Tall)', description: 'Phone wallpaper' },
]

export default function Home() {
  const [prompt, setPrompt] = useState('')
  const [imageCount, setImageCount] = useState(1)
  const [imageSize, setImageSize] = useState('1024x1024')
  const [isGenerating, setIsGenerating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [progressText, setProgressText] = useState('')
  const [images, setImages] = useState<ImageData[]>([])
  const [selectedImage, setSelectedImage] = useState<ImageData | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isLoadingImage, setIsLoadingImage] = useState(false)
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null)
  const [showDeleteAllDialog, setShowDeleteAllDialog] = useState(false)
  const [isDeletingAll, setIsDeletingAll] = useState(false)

  // Fetch user info on mount
  useEffect(() => {
    fetchUserInfo()
    fetchImages()
  }, [])

  const fetchUserInfo = async () => {
    try {
      const response = await fetch('/api/user-info')
      const data = await response.json()
      if (data.success) {
        setUserInfo(data.data)
      }
    } catch (error) {
      console.error('Failed to fetch user info:', error)
    }
  }

  const fetchImages = async () => {
    try {
      const response = await fetch('/api/images?limit=100')
      const data = await response.json()
      if (data.success) {
        setImages(data.data.images)
      }
    } catch (error) {
      console.error('Failed to fetch images:', error)
    }
  }

  const generateImages = async () => {
    if (!prompt.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a prompt',
        variant: 'destructive',
      })
      return
    }

    setIsGenerating(true)
    setProgress(0)
    setProgressText('Starting generation...')

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt.trim(),
          count: imageCount,
          size: imageSize,
        }),
      })

      const data = await response.json()

      if (data.success) {
        const total = data.data.total
        setProgressText(`Successfully generated ${total} image${total > 1 ? 's' : ''}!`)
        setProgress(100)
        
        toast({
          title: 'Success!',
          description: `Generated ${total} image${total > 1 ? 's' : ''} successfully`,
        })
        
        // Refresh images list
        await fetchImages()
        
        // Clear prompt after success
        setTimeout(() => {
          setPrompt('')
        }, 1000)
      } else {
        throw new Error(data.error || 'Failed to generate images')
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to generate images',
        variant: 'destructive',
      })
    } finally {
      setIsGenerating(false)
      setTimeout(() => {
        setProgress(0)
        setProgressText('')
      }, 2000)
    }
  }

  const viewImage = async (image: ImageData) => {
    setIsLoadingImage(true)
    setIsModalOpen(true)
    
    try {
      const response = await fetch(`/api/images/${image.id}`)
      const data = await response.json()
      
      if (data.success) {
        setSelectedImage(data.data)
      }
    } catch (error) {
      console.error('Failed to load image:', error)
      toast({
        title: 'Error',
        description: 'Failed to load image',
        variant: 'destructive',
      })
    } finally {
      setIsLoadingImage(false)
    }
  }

  const deleteImage = async (id: string) => {
    try {
      const response = await fetch(`/api/images/${id}`, {
        method: 'DELETE',
      })
      
      const data = await response.json()
      
      if (data.success) {
        toast({
          title: 'Deleted',
          description: 'Image deleted successfully',
        })
        setImages(prev => prev.filter(img => img.id !== id))
        if (selectedImage?.id === id) {
          setIsModalOpen(false)
          setSelectedImage(null)
        }
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete image',
        variant: 'destructive',
      })
    }
  }

  const deleteAllImages = async () => {
    setIsDeletingAll(true)
    try {
      const response = await fetch('/api/images/all', {
        method: 'DELETE',
      })
      
      const data = await response.json()
      
      if (data.success) {
        toast({
          title: 'Success',
          description: `Deleted ${data.deletedCount} images`,
        })
        setImages([])
        setIsModalOpen(false)
        setSelectedImage(null)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete all images',
        variant: 'destructive',
      })
    } finally {
      setIsDeletingAll(false)
      setShowDeleteAllDialog(false)
    }
  }

  const downloadImage = useCallback((image: ImageData) => {
    if (!image.imageData) return
    
    const link = document.createElement('a')
    link.href = `data:image/png;base64,${image.imageData}`
    link.download = `generated-${image.id}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    
    toast({
      title: 'Downloaded',
      description: 'Image saved to your device',
    })
  }, [])

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const getDeviceIcon = (device?: string) => {
    switch (device?.toLowerCase()) {
      case 'mobile':
        return <Smartphone className="w-4 h-4" />
      case 'tablet':
        return <Smartphone className="w-4 h-4" />
      default:
        return <Monitor className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-gray-900/95 backdrop-blur-sm border-b border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="p-1.5 sm:p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg sm:rounded-xl">
                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  AI Image Generator
                </h1>
                <p className="text-xs text-gray-400 hidden sm:block">Create stunning images with AI</p>
              </div>
            </div>
            
            {/* User Info Badge */}
            {userInfo && (
              <div className="flex items-center gap-1 sm:gap-2 text-xs text-gray-400">
                <Globe className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">{userInfo.ip}</span>
                <span className="sm:hidden">{userInfo.ip.slice(0, 10)}...</span>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-4 sm:py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Generator Panel */}
          <div className="lg:col-span-1 space-y-4">
            {/* Prompt Card */}
            <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm">
              <CardHeader className="pb-2 sm:pb-3">
                <CardTitle className="text-base sm:text-lg flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                  Generate Image
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 sm:space-y-4">
                {/* Prompt Input */}
                <div className="space-y-1.5 sm:space-y-2">
                  <Label className="text-xs sm:text-sm text-gray-300">Prompt</Label>
                  <Textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe the image you want to create..."
                    className="bg-gray-900/50 border-gray-600 focus:border-purple-500 focus:ring-purple-500/20 min-h-[80px] sm:min-h-[100px] text-sm resize-none"
                    disabled={isGenerating}
                  />
                </div>

                {/* Image Count */}
                <div className="space-y-1.5 sm:space-y-2">
                  <Label className="text-xs sm:text-sm text-gray-300">Number of Images</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      min={1}
                      max={20}
                      value={imageCount}
                      onChange={(e) => setImageCount(Math.min(20, Math.max(1, parseInt(e.target.value) || 1)))}
                      className="bg-gray-900/50 border-gray-600 focus:border-purple-500 w-20 text-sm"
                      disabled={isGenerating}
                    />
                    <div className="flex gap-1 flex-wrap">
                      {[1, 4, 10, 20].map((num) => (
                        <Button
                          key={num}
                          size="sm"
                          variant={imageCount === num ? 'default' : 'outline'}
                          onClick={() => setImageCount(num)}
                          className={`h-8 w-8 p-0 text-xs ${imageCount === num ? 'bg-purple-600 hover:bg-purple-700' : 'border-gray-600 hover:bg-gray-700'}`}
                          disabled={isGenerating}
                        >
                          {num}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Image Size */}
                <div className="space-y-1.5 sm:space-y-2">
                  <Label className="text-xs sm:text-sm text-gray-300">Image Size</Label>
                  <Select value={imageSize} onValueChange={setImageSize} disabled={isGenerating}>
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 focus:border-purple-500 text-sm">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {IMAGE_SIZES.map((size) => (
                        <SelectItem key={size.value} value={size.value} className="text-sm">
                          <div className="flex flex-col">
                            <span>{size.label}</span>
                            <span className="text-xs text-gray-400">{size.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Progress */}
                {isGenerating && (
                  <div className="space-y-2">
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-gray-400 flex items-center gap-2">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      {progressText}
                    </p>
                  </div>
                )}

                {/* Generate Button */}
                <Button
                  onClick={generateImages}
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium h-10 sm:h-11"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate {imageCount} Image{imageCount > 1 ? 's' : ''}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* User Info Card */}
            {userInfo && (
              <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm">
                <CardHeader className="pb-2 sm:pb-3">
                  <CardTitle className="text-base sm:text-lg flex items-center gap-2">
                    <Info className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                    Your Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 sm:space-y-3">
                  <div className="flex items-center justify-between py-1.5 sm:py-2 border-b border-gray-700/50">
                    <span className="text-xs sm:text-sm text-gray-400 flex items-center gap-1.5 sm:gap-2">
                      <Globe className="w-3 h-3 sm:w-4 sm:h-4" />
                      IP Address
                    </span>
                    <span className="text-xs sm:text-sm font-mono bg-gray-900/50 px-2 py-0.5 sm:py-1 rounded">{userInfo.ip}</span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 sm:py-2 border-b border-gray-700/50">
                    <span className="text-xs sm:text-sm text-gray-400 flex items-center gap-1.5 sm:gap-2">
                      {getDeviceIcon(userInfo.device)}
                      Browser
                    </span>
                    <span className="text-xs sm:text-sm">{userInfo.browser}</span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 sm:py-2 border-b border-gray-700/50">
                    <span className="text-xs sm:text-sm text-gray-400 flex items-center gap-1.5 sm:gap-2">
                      <Monitor className="w-3 h-3 sm:w-4 sm:h-4" />
                      OS
                    </span>
                    <span className="text-xs sm:text-sm">{userInfo.os}</span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 sm:py-2">
                    <span className="text-xs sm:text-sm text-gray-400 flex items-center gap-1.5 sm:gap-2">
                      <Smartphone className="w-3 h-3 sm:w-4 sm:h-4" />
                      Device
                    </span>
                    <Badge variant="outline" className="border-gray-600 text-xs">
                      {userInfo.device}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm">
              <CardContent className="pt-4 sm:pt-6">
                <Button
                  variant="destructive"
                  onClick={() => setShowDeleteAllDialog(true)}
                  disabled={images.length === 0 || isDeletingAll}
                  className="w-full h-10 sm:h-11"
                >
                  <Trash className="w-4 h-4 mr-2" />
                  Delete All Images ({images.length})
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Gallery */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm h-full">
              <CardHeader className="pb-2 sm:pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base sm:text-lg flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                    Gallery
                    <Badge variant="secondary" className="ml-2 text-xs">
                      {images.length}
                    </Badge>
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {images.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 sm:py-16 text-gray-400">
                    <ImageIcon className="w-12 h-12 sm:w-16 sm:h-16 mb-4 opacity-50" />
                    <p className="text-sm sm:text-base">No images generated yet</p>
                    <p className="text-xs sm:text-sm text-gray-500 mt-1">Enter a prompt and click Generate</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3 max-h-[500px] sm:max-h-[600px] overflow-y-auto pr-1 sm:pr-2 custom-scrollbar">
                    {images.map((image) => (
                      <div
                        key={image.id}
                        className="group relative aspect-square rounded-lg overflow-hidden bg-gray-700/30 cursor-pointer transition-all hover:ring-2 hover:ring-purple-500"
                        onClick={() => viewImage(image)}
                      >
                        <img
                          src={`/api/images/${image.id}?raw=true`}
                          alt={image.prompt}
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="absolute bottom-0 left-0 right-0 p-2">
                            <p className="text-xs text-white line-clamp-2">{image.prompt}</p>
                            <div className="flex items-center gap-1 mt-1">
                              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                                {image.size}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="icon"
                            variant="destructive"
                            className="h-6 w-6 sm:h-7 sm:w-7"
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteImage(image.id)
                            }}
                          >
                            <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Image Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl w-[95vw] sm:w-full bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg flex items-center gap-2">
              <ZoomIn className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
              Image Preview
            </DialogTitle>
          </DialogHeader>
          
          {isLoadingImage ? (
            <div className="flex items-center justify-center py-12 sm:py-16">
              <Loader2 className="w-6 h-6 sm:w-8 sm:h-8 animate-spin text-purple-400" />
            </div>
          ) : selectedImage ? (
            <div className="space-y-3 sm:space-y-4">
              {/* Image */}
              <div className="relative rounded-lg overflow-hidden bg-gray-800">
                <img
                  src={`data:image/png;base64,${selectedImage.imageData}`}
                  alt={selectedImage.prompt}
                  className="w-full max-h-[50vh] sm:max-h-[60vh] object-contain"
                />
              </div>
              
              {/* Info */}
              <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm">
                <div>
                  <span className="text-gray-400">Prompt: </span>
                  <span className="text-white">{selectedImage.prompt}</span>
                </div>
                <div className="flex flex-wrap gap-2 sm:gap-3">
                  <Badge variant="outline" className="border-gray-600 text-xs">
                    {selectedImage.size}
                  </Badge>
                  <Badge variant="outline" className="border-gray-600 text-xs flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDate(selectedImage.createdAt)}
                  </Badge>
                  {selectedImage.browser && (
                    <Badge variant="outline" className="border-gray-600 text-xs">
                      {selectedImage.browser}
                    </Badge>
                  )}
                </div>
              </div>
              
              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={() => downloadImage(selectedImage)}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 h-9 sm:h-10"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    window.open(`data:image/png;base64,${selectedImage.imageData}`, '_blank')
                  }}
                  className="border-gray-600 hover:bg-gray-700 h-9 sm:h-10"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => {
                    deleteImage(selectedImage.id)
                  }}
                  className="h-9 sm:h-10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Delete All Confirmation */}
      <AlertDialog open={showDeleteAllDialog} onOpenChange={setShowDeleteAllDialog}>
        <AlertDialogContent className="bg-gray-900 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              Delete All Images
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to delete all {images.length} images? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-gray-600 hover:bg-gray-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={deleteAllImages}
              className="bg-red-600 hover:bg-red-700"
              disabled={isDeletingAll}
            >
              {isDeletingAll ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete All
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Footer */}
      <footer className="border-t border-gray-700/50 mt-6 sm:mt-8 py-4 sm:py-6 text-center text-xs sm:text-sm text-gray-500">
        <p>AI Image Generator - Powered by Z.ai SDK</p>
      </footer>
    </div>
  )
}
